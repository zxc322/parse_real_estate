--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.12 (Debian 12.12-1.pgdg110+1)
-- Dumped by pg_dump version 12.12 (Debian 12.12-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE real_estate;
--
-- Name: real_estate; Type: DATABASE; Schema: -; Owner: zxc
--

CREATE DATABASE real_estate WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE real_estate OWNER TO zxc;

\connect real_estate

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: apartaments; Type: TABLE; Schema: public; Owner: zxc
--

CREATE TABLE public.apartaments (
    id integer NOT NULL,
    image character varying(2000) NOT NULL,
    title character varying(2000) NOT NULL,
    location character varying(100) NOT NULL,
    published_date character varying(50) NOT NULL,
    bedrooms character varying(100),
    description character varying(2000) NOT NULL,
    currency character varying(10),
    price character varying(100) NOT NULL
);


ALTER TABLE public.apartaments OWNER TO zxc;

--
-- Name: apartaments_id_seq; Type: SEQUENCE; Schema: public; Owner: zxc
--

CREATE SEQUENCE public.apartaments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.apartaments_id_seq OWNER TO zxc;

--
-- Name: apartaments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zxc
--

ALTER SEQUENCE public.apartaments_id_seq OWNED BY public.apartaments.id;


--
-- Name: apartaments id; Type: DEFAULT; Schema: public; Owner: zxc
--

ALTER TABLE ONLY public.apartaments ALTER COLUMN id SET DEFAULT nextval('public.apartaments_id_seq'::regclass);


--
-- Data for Name: apartaments; Type: TABLE DATA; Schema: public; Owner: zxc
--

COPY public.apartaments (id, image, title, location, published_date, bedrooms, description, currency, price) FROM stdin;
\.
COPY public.apartaments (id, image, title, location, published_date, bedrooms, description, currency, price) FROM '$$PATH$$/2958.dat';

--
-- Name: apartaments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zxc
--

SELECT pg_catalog.setval('public.apartaments_id_seq', 135, true);


--
-- Name: apartaments apartaments_pkey; Type: CONSTRAINT; Schema: public; Owner: zxc
--

ALTER TABLE ONLY public.apartaments
    ADD CONSTRAINT apartaments_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

